package feeds.examples.cql

import java.util.Date

import com.datastax.gatling.stress.core.BaseFeed
import com.typesafe.scalalogging.LazyLogging

import scala.collection.JavaConverters._


class CiscoFeed extends BaseFeed with LazyLogging {

  def write = {
    def rowData = getRowData

    // optionally log out the data that was generated for future use
    // logger.info("{},{},{}", Array(rowData.get("order_no"), rowData.get("cust_id"), rowData.get("email")))

    Iterator.continually(rowData)
  }

  def randomString(length: Int) = scala.util.Random.alphanumeric.take(length).mkString

  def getRowData = {
    Map(
      "id" -> faker.numerify("2############"),
      "doc" -> randomString(300)
    )
  }
}
