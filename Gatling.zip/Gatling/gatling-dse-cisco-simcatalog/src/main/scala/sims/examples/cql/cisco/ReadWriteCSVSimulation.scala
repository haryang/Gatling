package sims.examples.cql.cisco

import actions.examples.cql.CiscoActions
import com.datastax.gatling.plugin.CqlPredef._
import com.datastax.gatling.stress.core.BaseSimulation
import com.datastax.gatling.stress.libs.{FetchBaseData, SimConfig}
import feeds.examples.cql.CiscoFeed
import io.gatling.core.Predef._

class ReadWriteCSVSimulation extends BaseSimulation {

  val simName = "examples"

  /**
    * Start Write Scenario Setup
    */
  // load conf based on the simName and scenarioName from application.conf for writeOrderPercent
  val simConfWrite = new SimConfig(conf, simName, "pureWrite")

  // init orderWriteActions aka queries
  val ciscoWriteActions = new CiscoActions(cass, simConfWrite)

  // Load feed for generating data
  val ciscoWriteFeed = new CiscoFeed().write

  // build scenario to run with feed and write action
  val writeScenario = scenario("Write")
    .feed(ciscoWriteFeed)
    .exec(ciscoWriteActions.pureWrite)

  /**
    * End Write Scenario Setup
    */


  /**
    * Start Read Simulation
    */
  // load conf based on the simName and scenarioName from application.conf for writeOrderPercent
  val simConfRead = new SimConfig(conf, simName, "pureRead")

  // init orderReadActions aka queries
  val ciscoReadActions = new CiscoActions(cass, simConfRead)

  // create base data file using config values
  new FetchBaseData(simConfRead, cass).createBaseDataCsv()

  val feederFile = getDataPath(simConfRead)
  val csvFeeder = csv(getDataPath(simConfRead)).random

  val readScenario = scenario("Read")
    .feed(csvFeeder)
    .exec(ciscoReadActions.pureRead)
  /**
    * End Read Scenario Setup
    */

  // setup the traffic to run w/ the scenario
  setUp(
    // Both scenarios will be run at the same time asynchronously
    loadGenerator.rampUpToConstant(writeScenario, simConfWrite),
    loadGenerator.rampUpToConstant(readScenario, simConfRead)
  ).protocols(cqlProtocol)

}
