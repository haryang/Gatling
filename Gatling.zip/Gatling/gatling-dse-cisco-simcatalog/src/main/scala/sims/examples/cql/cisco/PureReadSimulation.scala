package sims.examples.cql.cisco

import actions.examples.cql.CiscoActions
import com.datastax.gatling.plugin.CqlPredef._
import com.datastax.gatling.stress.core.BaseSimulation
import com.datastax.gatling.stress.libs.{FetchBaseData, SimConfig}
import io.gatling.core.Predef._

class PureReadSimulation extends BaseSimulation {

  val simName = "examples"
  val scenarioName = "pureRead"

  val simConf = new SimConfig(conf, simName, scenarioName)

  val ciscoActions = new CiscoActions(cass, simConf)

  // create base data file using config values
  new FetchBaseData(simConf, cass).createBaseDataCsv()

  val feederFile = getDataPath(simConf)
  val csvFeeder = csv(feederFile).random

  val readScenario = scenario("PureRead")
    .feed(csvFeeder)
    .exec(ciscoActions.pureRead)

  setUp(
    loadGenerator.rampUpToConstant(readScenario, simConf)
  ).protocols(cqlConfig)
}
