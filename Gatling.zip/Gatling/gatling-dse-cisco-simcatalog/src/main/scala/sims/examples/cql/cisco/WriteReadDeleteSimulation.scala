package sims.examples.cql.cisco

import actions.examples.cql.CiscoActions
import com.datastax.gatling.plugin.CqlPredef._
import com.datastax.gatling.stress.core.BaseSimulation
import com.datastax.gatling.stress.libs.SimConfig
import feeds.examples.cql.CiscoFeed
import io.gatling.core.Predef._

class WriteReadDeleteSimulation extends BaseSimulation {

  val simName = "examples"

  // load conf based on the simName and scenarioName from application.conf for writeOrderPercent
  val simConf = new SimConfig(conf, simName, "WRD")

  // init orderWriteActions aka queries
  val ciscoActions = new CiscoActions(cass, simConf)

  // Load feed for generating data
  val ciscoFeed = new CiscoFeed().write

  // build scenario to run with feed and write action
  val wrdScenario = scenario("Write Read Delete")
    .feed(ciscoFeed)
    .exec(ciscoActions.pureWrite)
    .exec(ciscoActions.pureRead)
    .exec(ciscoActions.pureDelete)

  val addScenario = scenario("Additional Actions")
    .feed(ciscoFeed)
    .exec(ciscoActions.pureWrite)
    .exec(ciscoActions.pureRead)
    .exec(ciscoActions.pureDelete)

  setUp(
    loadGenerator.rampUpToConstant(wrdScenario, simConf)//,
    //loadGenerator.rampUpToConstant(addScenario, simConf)

  ).protocols(cqlProtocol)

}