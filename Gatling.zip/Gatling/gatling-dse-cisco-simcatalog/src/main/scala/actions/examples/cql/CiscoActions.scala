package actions.examples.cql

import com.datastax.driver.core.ConsistencyLevel
import com.datastax.driver.core.querybuilder.QueryBuilder
import com.datastax.driver.core.querybuilder.QueryBuilder._
import com.datastax.gatling.plugin.CqlPredef._
import com.datastax.gatling.stress.core.BaseAction
import com.datastax.gatling.stress.libs.{Cassandra, SimConfig}
import io.gatling.core.Predef._

/**
  * Order Actions
  *
  * @param cassandra Cassandra
  * @param simConf   SimConf
  */
class CiscoActions(cassandra: Cassandra, simConf: SimConfig) extends BaseAction(cassandra, simConf) {

  // create keyspace/table if they do not exist
  createKeyspace
  createTables()

  // A regular string query can be used as well as the QueryBuilder
  private val pureWriteQuery = QueryBuilder.insertInto(keyspace, table)
    .value("id", raw("?"))
    .value("doc", raw("?"))


  def pureWrite = {

    val preparedStatement = session.prepare(pureWriteQuery)

    group(Groups.INSERT) {
      exec(cql("Metadata")
        .executePrepared(preparedStatement)
        .withParams(
          "${id}",
          "${doc}"
        )
        .consistencyLevel(ConsistencyLevel.QUORUM) // ConsistencyLevel can be set per query
        .check(rowCount is 0) // an insert should not return rows
      )
    }
  }

  val readOrderQuery = QueryBuilder.select().from(keyspace, table).where(QueryBuilder.eq("id", raw("?")))

  def pureRead = {

    val preparedStatement = session.prepare(readOrderQuery)

    group(Groups.SELECT) {
      exec(cql("Metadata")
        .executePrepared(preparedStatement)
        .withParams(
          "${id}"
        )
        .check(rowCount greaterThan 0)
      )
    }
  }

  val deleteOrderQuery = QueryBuilder.delete().from(keyspace, table).where(QueryBuilder.eq("id", raw("?")))

  def pureDelete = {

    val preparedStatement = session.prepare(deleteOrderQuery)

    group(Groups.DELETE) {
      exec(cql("Metadata")
        .executePrepared(preparedStatement)
        .withParams(
          "${id}"
        )
        .check(rowCount is 0)
      )
    }
  }

  def createTables(): Unit = {

    runQueries(Array(

      s"""CREATE TABLE IF NOT EXISTS $keyspace.$table (
          id text,
          doc text,
          PRIMARY KEY (id)
        ) WITH compaction = {'class': 'LeveledCompactionStrategy'}
          AND gc_grace_seconds = 172800;"""
    ))

  }

}
