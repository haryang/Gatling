package sims.examples.cql.cisco

import actions.examples.cql.CiscoActions
import com.datastax.gatling.plugin.CqlPredef._
import com.datastax.gatling.stress.core.BaseSimulation
import com.datastax.gatling.stress.libs.SimConfig
import feeds.examples.cql.CiscoFeed
import io.gatling.core.Predef._

class ReadWriteSimulation extends BaseSimulation {

  val simName = "examples"

  // load conf based on the simName and scenarioName from application.conf for writeOrderPercent
  val simConf = new SimConfig(conf, simName, "readWrite")

  // init orderWriteActions aka queries
  val ciscoActions = new CiscoActions(cass, simConf)

  // Load feed for generating data
  val ciscoFeed = new CiscoFeed().write

  // build scenario to run with feed and write action
  val rwScenario = scenario("Read and Write")
    .feed(ciscoFeed)
    .exec(ciscoActions.pureWrite)
    .exec(ciscoActions.pureRead)

  setUp(
    loadGenerator.rampUpToConstant(rwScenario, simConf)
  ).protocols(cqlProtocol)

}